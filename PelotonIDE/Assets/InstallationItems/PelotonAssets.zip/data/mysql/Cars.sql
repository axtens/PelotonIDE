-- ----------------------------------------------------------------------
-- MySQL Migration Toolkit
-- SQL Create Script
-- ----------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `cars`
  CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cars`;
-- -------------------------------------
-- Tables

DROP TABLE IF EXISTS `cars`.`Booking`;
CREATE TABLE `cars`.`Booking` (
  `Booking Number` VARCHAR(10) NOT NULL,
  `Date Booked` DATETIME NULL,
  `Date Vehicle Needed` DATETIME NULL,
  `Vehicle ID Num` VARCHAR(10) NULL,
  `Customer ID Num` VARCHAR(10) NULL,
  `Driver ID Num` VARCHAR(10) NULL,
  `Time to Pick Up` DATETIME NULL,
  `Collected` TINYINT(1) NOT NULL,
  `Date Cancelled` DATETIME NULL,
  `Cancelled` TINYINT(1) NOT NULL,
  `Deposit` DECIMAL(19, 4) NULL,
  `Deposit Paid` TINYINT(1) NOT NULL,
  `Expected Mileage` INT(10) NULL,
  PRIMARY KEY (`Booking Number`),
  INDEX `Customer ID Num` (`Customer ID Num`),
  INDEX `Driver ID Num` (`Driver ID Num`),
  INDEX `Vehicle ID Num` (`Vehicle ID Num`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cars`.`Customer`;
CREATE TABLE `cars`.`Customer` (
  `Customer ID Num` VARCHAR(10) NOT NULL,
  `Customer Name` VARCHAR(25) NULL,
  `Address` VARCHAR(35) NULL,
  `Date Of Birth` DATETIME NULL,
  `Phone Num` VARCHAR(15) NULL,
  `Driver License Number` VARCHAR(20) NULL,
  `LastName` VARCHAR(50) NULL,
  `Occupation` VARCHAR(50) NULL,
  `Verified` TINYINT(1) NOT NULL,
  `Comments` LONGTEXT NULL,
  PRIMARY KEY (`Customer ID Num`),
  INDEX `Customer ID Num` (`Customer ID Num`),
  INDEX `Phone Num` (`Phone Num`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cars`.`Employee`;
CREATE TABLE `cars`.`Employee` (
  `Employee ID Num` VARCHAR(10) NOT NULL,
  `Employee Name` VARCHAR(25) NULL,
  `Job Title` VARCHAR(20) NULL,
  `Hourly Wage Rate` DECIMAL(19, 4) NULL,
  `Phone Number` VARCHAR(15) NULL,
  PRIMARY KEY (`Employee ID Num`),
  INDEX `Employee ID Num` (`Employee ID Num`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cars`.`Hours Worked`;
CREATE TABLE `cars`.`Hours Worked` (
  `Employee Number` VARCHAR(10) NOT NULL,
  `Date Worked` DATETIME NOT NULL,
  `Time In` DATETIME NOT NULL,
  `Time Out` DATETIME NULL,
  PRIMARY KEY (`Employee Number`, `Date Worked`, `Time In`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cars`.`Payments`;
CREATE TABLE `cars`.`Payments` (
  `Payment Number` VARCHAR(10) NOT NULL,
  `Booking Number` VARCHAR(10) NULL,
  `Amount Paid` DECIMAL(19, 4) NULL,
  `Date Paid` DATETIME NULL,
  PRIMARY KEY (`Payment Number`),
  INDEX `Amount Paid` (`Amount Paid`),
  INDEX `Date Paid` (`Date Paid`)
)
ENGINE = INNODB;

DROP TABLE IF EXISTS `cars`.`Vehicle`;
CREATE TABLE `cars`.`Vehicle` (
  `Vehicle ID Num` VARCHAR(10) NOT NULL,
  `Make` VARCHAR(15) NULL,
  `Name` VARCHAR(15) NULL,
  `Color` VARCHAR(15) NULL,
  `Number of Seats` SMALLINT(5) NULL,
  `Self Drive?` TINYINT(1) NOT NULL,
  `Price Per Day` DECIMAL(19, 4) NULL,
  PRIMARY KEY (`Vehicle ID Num`),
  INDEX `Number of Seats` (`Number of Seats`),
  INDEX `Vehicle ID Num` (`Vehicle ID Num`)
)
ENGINE = INNODB;



SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------------
-- EOF

