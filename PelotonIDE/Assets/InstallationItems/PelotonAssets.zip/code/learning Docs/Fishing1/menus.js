
function initmenu() {

   var detect = navigator.userAgent.toLowerCase();

    if( detect.indexOf("opera") == -1 )
    if (document.all &&
        document.getElementById
       ) {

    navRoot = document.getElementById('menu');

    for (i=0; i<navRoot.childNodes.length; i++) {

      node = navRoot.childNodes[i];

      if (node.nodeName=="LI" || node.nodeName=="li") {

        node.onmouseover=function() {
          this.className="over";
        }

	    node.onmouseout=function() {
          this.className="";
        }

	    node.onfocus=function() {
          this.className="over";
        }

	    node.onblur=function() {
          this.className="";
        }
      }
    }
  }
};

