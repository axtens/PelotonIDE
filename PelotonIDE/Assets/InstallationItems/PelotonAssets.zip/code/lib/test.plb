<@ DEFUDOLITLITLIT>BMP|__transformer|
	par 1 thre times <@ SAYPAR>1</@> <@ SAYPAR>1</@> <@ SAYPAR>1</@>
</@>
<@ DEFUDOLITLITLIT>BTM|__transformer|
	par 1 twice <@ SAYPAR>1</@> <@ SAYPAR>1</@>
</@>
<@ DEFUDOLITLITLIT>NWN|__transformer|
	par 1 <@ SAYPAR>1</@>
</@>
