Setting up generalised code block
<@ OMT>Defining a code block to both read, and to force an exit on a read error</@>
<@ DEFUDRLIT>resultanddumprec|
	Result: <@ SAYKEY>__pluginanswer</@>
	<@ IFEEBNKEYLIT>__pluginsuccess|
		Record: (<@ SAYACTCMDPLGLIT>__RecordpointerPosition</@>) <@ SAYACTCMDPLGLIT>__RecordRead0DSerialisedValues</@>
	</@>
	<@ els>
		error reading record! - exiting<@ ACTBRK></@> 
	</@>
</@>
