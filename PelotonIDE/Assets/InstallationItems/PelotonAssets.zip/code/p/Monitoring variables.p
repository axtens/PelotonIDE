<@ LETVARLIT>acc|12</@>

<@ DEFMORLIT>ON</@><BR>
<@ DEFMORLITLIT>m|right <@ ACTADDVARVAR>acc2|m</@><@ SAYVAR>acc2</@><@ ACTAST></@><BR></@>


<@ DEFMOLLIT>ON</@><BR>
<@ DEFMOLLITLIT>m|left <@ ACTADDVARVAR>acc|m</@><@ SAYVAR>acc</@><@ ACTAST></@><BR></@>
<@ LETVARLIT>acc2|2</@>
<@ LETVARLIT>m|3</@><@ SAYVAR>m</@> [acc <@ SAYVAR>acc</@>] {acc2 <@ SAYVAR>acc2</@>}<BR>
<@ LETVARLIT>m|7</@><@ SAYVAR>m</@> [acc <@ SAYVAR>acc</@>] {acc2 <@ SAYVAR>acc2</@>}<BR>
<@ LETVARLIT>m|4</@><@ SAYVAR>m</@> [acc <@ SAYVAR>acc</@>] {acc2 <@ SAYVAR>acc2</@>}<BR>
<@ LETVARLIT>m|2</@><@ SAYVAR>m</@> [acc <@ SAYVAR>acc</@>] {acc2 <@ SAYVAR>acc2</@>}<BR>
<@ LETVARLIT>m|5</@><@ SAYVAR>m</@> [acc <@ SAYVAR>acc</@>] {acc2 <@ SAYVAR>acc2</@>}<BR>

[<@ SAYVAR>acc</@>]
[<@ SAYVAR>acc2</@>]
