this is a thing
<@ GETVARFLE>junk</@>
you selected the file <@ SAYVAR>junk</@>
<@ GETVARDIR>junk</@>
you selected the directory <@ SAYVAR>junk</@>
