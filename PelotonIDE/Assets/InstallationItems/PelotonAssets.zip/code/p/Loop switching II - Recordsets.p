<HR>
<H3>enumerated recordset banded in 10s</H3>
<@ DEFDBF>\web\splsite\projects\test.mdb</@>
<@ DEFRST>select * from tblClients order by BusinessName</@>
<@ ITERST>
<@ INI>Printing out field BusinessName</@>
<@ GRPLITLIT>10|<HR>Grouping in 10s, we are at number <@ SAYPOSRST>__current</@><hr> </@> 

<@ SAYPOSRST></@> - <@ SAYFLD>BusinessName</@> <BR>
<@ FIN>BYE BYE then</@>

</@>

<HR>
<H3>enumerated recordset grouped by a changing value</H3>
<@ DEFDBF>test.mdb</@>
<@ DEFRST>select * from customers order by country</@>
<@ ITERST>
<@ INI>Printing out Company Name and Fax by Country<HR></@>
<@ CHGLITLITLIT> <@ PUTFLD>country</@>| <LI><@ SAYFLD>country</@> <BR> | <@ SAYVAR>counter</@> records found for &LastValue; <@ LETVARLIT>counter|0</@><BR></@>
<@ SAYPOSRST></@> - <@ SAYFLD>CompanyName</@> 
<@ IFFNOTNULFLDLIT>fax| Fax: <@ SAYFLD>Fax</@> <@ ACTADDVARLIT>hasfax|1</@></@>
<BR>
<@ ACTADDVARLIT>counter|1</@> 
<@ FIN><HR>Report complete: <@ SAYSZERST></@> records <@ SAYVAR>hasfax</@> with faxes</@>
</@>

<HR>
<H3>enumerated recordset testing BRL and ONC</H3>
<@ DEFDBF>test.mdb</@>
<@ DEFRST>select * from tblClients order by BusinessName</@>
<@ ITERST>
<@ INI>Printing out field BusinessName</@>
<@ GRPLITLIT>10|<HR>Grouping in 10s, we are at number <@ SAYPOSRST>__current</@><hr> </@> 

<@ SAYPOSRST></@> - <@ SAYFLD>BusinessName</@> <BR>
<@ FIN>BYE BYE then</@>
<@ ONCLITLIT><@ TSTPOSRSTLIT>counter|7</@>|<@ ACTBRL></@>leaving after 7!</@>

</@>
