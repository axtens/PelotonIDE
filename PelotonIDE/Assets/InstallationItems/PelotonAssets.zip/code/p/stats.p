 Constructing (CNS) a queue from a deal (DEA) of random numbers, duping (DUP) it a few times so that the subsequent is meaningful<@ LETCNSDEAQUELITLITLIT>q|6|100|9</@>, <@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@> and dumping (DMP) it:{<@ SAYDMPQUELITLIT>q|,|}</@>
Reducing (RED) q via statistical functions: 

average of the absolute deviations (AVD) <@ SAYAVDREDQUE>q</@>
average (AVG) <@ SAYAVGREDQUE>q</@>
geometric mean (GMN) <@ SAYGMNREDQUE>q</@>
harmonic mean (HMN) <@ SAYHMNREDQUE>q</@>
kurtosis (KRT) <@ SAYKRTREDQUE>q</@>
lower quartile (LQU) <@ SAYLQUREDQUE>q</@>
maximum (MAX) <@ SAYMAXREDQUE>q</@>
median (MDN) <@ SAYMDNREDQUE>q</@>
minimum (MIN) <@ SAYMINREDQUE>q</@>
40% percentile (PTL) <@ SAYPTLREDQUELIT>q|.4</@>
Face percentile rank(PTR) <@ SAYPTRREDQUEQUE>q|q</@>
skew (SKW) <@ SAYSKWREDQUE>q</@>

sum of squares (SSQ) <@ SAYSSQREDQUE>q</@>
sum of squares of deviations (DVQ) <@ SAYDVQREDQUE>q</@>
standard deviation  (STD) <@ SAYSTDREDQUE>q</@>

population standard deviation  (SDP) <@ SAYSDPREDQUE>q</@>

span (range) (SPN) <@ SAYSPNREDQUE>q</@>
upper quartile (UQU) <@ SAYUQUREDQUE>q</@>
variance (VRN) <@ SAYVRNREDQUE>q</@>
population variance (VPN) <@ SAYVPNREDQUE>q</@>
rank (RNK) of face value (<@ SAYQUE>q</@>) <@ SAYRNKREDQUEQUE>q|q</@>
mode (MDE) <@ SAYMDEREDQUE>q</@>
frequency of face-value (FRQ) <@ SAYFRQREDQUEQUE>q|q</@>
number of unique (UNQ) <@ SAYUNQREDQUE>q</@> vs. count (SZE) <@ SAYSZEQUE>q</@>



