Queue as entity:<BR>
<@ LETCNSQUELIT>q|neverthless^the^albert^memorial^doesn't^match^your^eyes^</@> 
 <@ SAYDMPQUE>q</@> <br>
NIP: <@ ACTNIPENTQUE>q</@> <@ SAYDMPQUE>q</@> <br>
DUP: <@ ACTDUPENTQUE>q</@> <@ SAYDMPQUE>q</@> <br>
SHF: <@ ACTSHFENTQUE>q</@> <@ SAYDMPQUE>q</@> <br>
SRT: <@ ACTSRTENTQUE>q</@> <@ SAYDMPQUE>q</@> <br>
POP: <@ ACTPOPENTQUE>q</@> <@ SAYDMPQUE>q</@> <br>
ZAP: <@ ACTZAPENTQUE>q</@> <@ SAYDMPQUE>q</@> <br>

<HR>
Queue face as letters:<BR>
<@ LETCNSQUELIT>q|neverthless^the^albert^memorial^doesn't^match^your^eyes^</@> 
DMP: <@ SAYDMPQUE>q</@> <br>
NIP: <@ ACTNIPQUE>q</@> <@ SAYDMPQUE>q</@> <br>
DUP: <@ ACTDUPQUE>q</@> <@ SAYDMPQUE>q</@> <br> 
SHF: <@ ACTSHFQUE>q</@> <@ SAYDMPQUE>q</@>  <br>
SRT: <@ ACTSRTQUE>q</@> <@ SAYDMPQUE>q</@>  <br>
POP: <@ ACTPOPQUE>q</@> <@ SAYDMPQUE>q</@>  <br>
ZAP: <@ ACTZAPQUE>q</@> <@ SAYDMPQUE>q</@>  <br>
<HR>
Queue face as words:<BR>
<@ LETCNSQUELIT>q|the albert memorial doesn't match your eyes^and westham baths I know you'd spurn^</@> <@ SAYDMPQUE>q</@> <br>
NIP: <@ ACTNIPWRDQUE>q</@> <@ SAYDMPQUE>q</@> <br>
DUP: <@ ACTDUPWRDQUE>q</@> <@ SAYDMPQUE>q</@> <br>
SHF: <@ ACTSHFWRDQUE>q</@> <@ SAYDMPQUE>q</@> <br>
SRT: <@ ACTSRTWRDQUE>q</@> <@ SAYDMPQUE>q</@> <br>
POP: <@ ACTPOPWRDQUE>q</@> <@ SAYDMPQUE>q</@> <br>
ZAP: <@ ACTZAPWRDQUE>q</@> <@ SAYDMPQUE>q</@> <br>

<HR>
Queue face as 4-character segments:<BR>
<@ LETCNSQUELIT>q|the albert memorial doesn't match your eyes^and westham baths I know you'd spurn^</@> 
<@ SAYDMPQUE>q</@> <br> 
NIP: <@ ACTNIPSEGQUELIT>q|4</@> <@ SAYDMPQUE>q</@> <br>
DUP: <@ ACTDUPSEGQUELIT>q|4</@> <@ SAYDMPQUE>q</@> <br>
SHF: <@ ACTSHFSEGQUELIT>q|4</@> <@ SAYDMPQUE>q</@> <br>
SRT: <@ ACTSRTSEGQUELIT>q|4</@> <@ SAYDMPQUE>q</@> <br>
POP: <@ ACTPOPSEGQUELIT>q|4</@> <@ SAYDMPQUE>q</@> <br>
ZAP: <@ ACTZAPSEGQUELIT>q|4</@> <@ SAYDMPQUE>q</@> <br>
<HR>
Queue face as tokens (delimited by +):<BR>
<@ LETCNSQUELIT>q|the albert+memorial+doesn't match your+eyes^and westham baths I know you'd spurn^</@> 
<@ SAYDMPQUE>q</@> <br>
NIP: <@ ACTNIPTOKQUELIT>q|+</@> <@ SAYDMPQUE>q</@> <br>
DUP: <@ ACTDUPTOKQUELIT>q|+</@> <@ SAYDMPQUE>q</@> <br>
SHF: <@ ACTSHFTOKQUELIT>q|+</@> <@ SAYDMPQUE>q</@> <br>
SRT: <@ ACTSRTTOKQUELIT>q|+</@> <@ SAYDMPQUE>q</@> <br>
POP: <@ ACTPOPTOKQUELIT>q|+</@> <@ SAYDMPQUE>q</@> <br>
ZAP: <@ ACTZAPTOKQUELIT>q|+</@> <@ SAYDMPQUE>q</@> <br>
