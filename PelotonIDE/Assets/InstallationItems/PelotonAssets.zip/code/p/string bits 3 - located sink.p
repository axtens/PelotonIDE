 <@ SAYLETVARLIT>j|The cat sat the rat on the mat</@><BR>
<@ SAYACTREPVARLITLIT>j|rat|bat</@>
<@ LETLFTVARLITLIT>j|cat|It was a brat that</@>
<@ LETRITVARLITLIT>j|mat|slat in the rain</@><BR>
<@ SAYVAR>j</@>
