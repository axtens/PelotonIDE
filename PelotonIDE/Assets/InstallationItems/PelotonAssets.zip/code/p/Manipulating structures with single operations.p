<@ DEFUDSLITLIT>QUD|transformer|{<@ SAYREPLOPDMPQUELITLIT>q|^|,</@>}</@>
Constructing (CNS) a queue from a deal (DEA) of random numbers <@ LETCNSDEAQUELITLITLIT>q|6|100|9</@>  and dumping (DMP) the contents of q <@ SAYQUD></@>
Shuffling (SHF) q<@ ACTSHFENTQUE>q</@> <@ SAYQUD></@>
Inverting (INV) q<@ ACTINVENTQUE>q</@> <@ SAYQUD></@>
Rotating (ROT) 2 elements of q 3 times starting at 4<@ ACTAST></@><@ ACTROTENTQUELITLITLIT>q|4|3|2</@> <@ SAYQUD></@>
Sorting (SRT) q <@ ACTSRTENTQUE>q</@> <@ SAYQUD></@>
Reducing (RED) q via addition <@ SAYADDREDQUE>q</@>
Reducing q via multiplication <@ SAYMULREDQUE>q</@>
Reducing q via multiplication and assigning to a new variable
<@ LETMULVARREDQUE>total|q</@>total is <@ SAYVAR>total</@>
Multiplication by 3 over (OVR)  q <@ ACTMULOVRQUELIT>q|3</@> <@ SAYQUD></@>
Addition of 2 over q <@ ACTADDOVRQUELIT>q|2</@><@ SAYQUD></@>
Addition of 2 over q (again) <@ ACTADDOVRQUELIT>q|2</@><@ SAYQUD></@>
Saying another addition of 2 over q
<@ SAYADDOVRQUELIT>q|2</@> 
and another again<@ SAYADDOVRQUELIT>q|2</@>(implicit dumping - note how original values are unchanged)
Indexed (IND) - ie direct - access to elements:
Face-value (default) <@ SAYQUE>q</@> 
2nd <@ SAYINDQUELIT>q|2</@> 
3rd <@ SAYINDQUELIT>q|3</@> 
3rd last <@ SAYINDQUELIT>q|-3</@> 
2nd last <@ SAYINDQUELIT>q|-2</@>
Duplicating (DUP) the first element of q <@ ACTDUPENTQUE>q</@> <@ SAYQUD></@>
Popping (POP) q <@ ACTPOPENTQUE>q</@> <@ SAYQUD></@>
Nipping (NIP) q <@ ACTNIPENTQUE>q</@> <@ SAYQUD></@>
Taking (TKE) first 3 elements from q <@ SAYTKEQUELIT>q|3</@>
Dropping (DRP) 3 from q <@ ACTDRPENTQUELIT>q|3</@><@ SAYQUD></@>
Zapping (ZAP) q <@ ACTZAPENTQUE>q</@> 
{<@ SAYREPDMPQUELITLIT>q|^|,</@>}
