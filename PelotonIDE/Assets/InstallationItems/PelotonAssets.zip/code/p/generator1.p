<@ DEFAREGEN>test</@>
<@ DEFGENLITLITLIT>test|<@ ACTINCGVR></@><@ IFFGVRLITLIT>|25|<@ LETGVRKEY>|pi</@></@></@>
<@ DEFAREGEN>test2</@>
<@ DEFGENLITLITLIT>test2|<@ ACTMULGVRLIT>|3</@>|8</@>



<@ SAYGEN>test</@>

<@ SAYGEN>test2</@>
<@ SAYGEN>test</@>
<@ SAYGEN>test</@>
<@ SAYADDGENLIT>test2|4</@>
<@ SAYGEN>test</@>
<@ SAYGEN>test</@>
<@ LETVARGEN>t|test2</@>
<@ SAYVAR>t</@>
<@ DEFAREFOR>fred</@>
<@ ITEFORLITLIT>23|
<BR><@ SAYELTFOR>fred</@>=<@ SAYGEN>test</@>
</@>


<@ DEFAREGEN>test3</@>
<@ DEFGENLITLIT>test3|<@ LETRN0GVRLITLIT>|1|600</@></@>
<@ ITEFORLITLIT>8|
<BR><@ SAYELTFOR>fred</@>=<@ SAYGEN>test3</@>
</@>


<@ ITEFORLITLIT>10|
<BR><@ SAYELTFOR>fred</@>=<@ SAYADDGENGEN>test3|test</@>
</@>
