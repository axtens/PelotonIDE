<@ DEFTRN>__ConsoleTransput</@>
press any key, I'll tell you the ASCII <@ GETINNVAR>a single char</@>
you pressed <@ SAYVAR>a single char</@>
press another key <@ GETINPVAR>a single char</@>
<@ SAYVAR>a single char</@>
What's your family name <@ GETPRPVAR>famname</@>
What's your given name <@ GETPRPVAR>personal</@>
What name order do you prefer? <@ GETPKLVARlit>nameorder|Given then family^Family then given^</@>
<@ IFEVARLITLIT>nameorder|1|
	Hi <@ SAYCWSVARVAR>personal|famname</@>
</@>
<@ ELS>
	Hi <@ SAYCWSVARVAR>famname|personal</@>
</@>
