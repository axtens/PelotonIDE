<@ BLK>zorro| paid out <@ SAYKEY>now</@></@>
<@ KOP>LVL|LETVARLIT</@>
<@ LVL>Service|17</@>
<@ LVL>Sex|f</@>
<@ LVL>Age|43</@>
<@ AREDTB>Bonuses paid</@>
<@ DTC>&Service; > 10|?|Y^Y^Y^Y^N^N^-^-</@>
<@ DTC>&Sex;|'|M^F^M^F^M^F^M^F</@>
<@ DTC>&Age;|,|50,60^50,60^40,49^40,49^30,39^30,39^0,29^0,29</@>
<@ DTA>&Bonus Paid;|=|90^70^80^60^50^-^-^-</@>
<@ DTA>Rate for females|!|-^X^-^X^-^-^-^-</@>
<@ DTA>Rate for males|!|X^-^X^-^X^-^-^-</@>
<@ DTA>zorro|*|X^X^X^X^X^-^-^-</@>
<@ ACTDTB>Bonuses paid</@>
$<@ SAYVAR>Bonus Paid</@>
