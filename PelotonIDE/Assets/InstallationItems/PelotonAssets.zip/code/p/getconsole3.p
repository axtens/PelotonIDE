<@ LETVARLIT>famname|Smith</@>
<@ LETVARLIT>personal|John</@>
<@ LETVARLIT>nameorder|1</@>
<@ DEFTRN>-3</@>
<@ GETWGTLITLIT>What's your family name?|Enter details</@>
<@ GETPRPVAR>famname</@>
<@ GETWGTLITLIT>What's your given name?|Enter details</@>
<@ GETPRPVAR>personal</@>
<@ GETWGTLITLIT>What name order do you prefer?|Pick one</@>
<@ GETPKLVARlit>nameorder|Given then family^Family then given^</@>
<@ IFEVARLITLIT>nameorder|1|
	<@ SAYCAP>Hi <@ SAYCWSVARVAR>personal|famname</@></@>
</@>
<@ ELS>
	<@ SAYCAP>Hi <@ SAYCWSVARVAR>famname|personal</@></@>
</@>
<@ GETWGTLITLIT>Was that right?|Was that the correct form?</@>
<@ GETCHKVAR>correct</@>
<@ IFEBLNVARLIT>correct|
	Thank goodness!
</@>
<@ ELS>
	Sorry!
</@>