<@ LETVARLIT>j|This is not a test</@>
[<@ SAYVAR>j</@>]<BR>
<HR>Numeric<HR>
Right [<@ SAYRITVAR>j|5</@>]<BR>
Left [<@ SAYLFTVAR>j|5</@>]<BR>
BL [<@ SAYBLLVAR>j|5</@>]<BR>
BR [<@ SAYBLRVAR>j|5</@>]<BR>
<HR>Letter<HR>
Right [<@ SAYRITVAR>j|n</@>]<BR>
Left [<@ SAYLFTVAR>j|n</@>]<BR>
BL [<@ SAYBLLVAR>j|n</@>]<BR>
BR [<@ SAYBLRVAR>j|n</@>]<BR>
Upto [<@ SAYUPTVAR>j|n</@>]<BR>
Rev Upto [<@ SAYUPRVAR>j|n</@>]<BR>
After [<@ SAYAFTVAR>j|n</@>]<BR>
Before [<@ SAYBEFVAR>j|n</@>]<BR>
<HR>String<HR>
Right [<@ SAYRITVAR>j|not</@>]<BR>
Left [<@ SAYLFTVAR>j|not</@>]<BR>
BL [<@ SAYBLLVAR>j|not</@>]<BR>
BR [<@ SAYBLRVAR>j|not</@>]<BR>
Upto [<@ SAYUPTVAR>j|not</@>]<BR>
Rev Upto [<@ SAYUPRVAR>j|not</@>]<BR>
After [<@ SAYAFTVAR>j|not</@>]<BR>
Before [<@ SAYBEFVAR>j|not</@>]<BR>
