<@ DEFDBF>sc.mdb</@>
<@ DEFARE>All</@>
<@ RST>tblClients</@>
<@ ITERST>
	<@ SAYFLD>BusinessName</@> <@ SAYFLD>Proprietor</@> <@ SAYFLD>FirstName</@>
	<@ SAYLETVARFLD>ClientFK|ClientID</@>

	<@ DEFARE>JustTheOneType</@>
		Types
		<@ RSTCAP>SELECT tblClientCats.ClientFK, tblCats.strName, tblCats.StrType FROM tblClientCats INNER JOIN tblCats ON tblClientCats.GeneralCategoryFK = tblCats.idNode WHERE tblClientCats.ClientFK=<@ SAYVAR>ClientFK</@> AND tblCats.StrType="t" ORDER BY tblCats.strName</@>
		<@ ITERST>

			[<@ SAYFLD>strName</@>]

		</@>

	
	<@ DEFARE>JustTheOneBrand</@>
		Brands
		<@ RSTCAP>SELECT tblClientCats.ClientFK, tblCats.strName, tblCats.StrType FROM tblClientCats INNER JOIN tblCats ON tblClientCats.GeneralCategoryFK = tblCats.idNode WHERE tblClientCats.ClientFK=<@ SAYVAR>ClientFK</@> AND tblCats.StrType="b" ORDER BY tblCats.strName</@>
		<@ ITERST>
			[<@ SAYFLD>strName</@>]
		</@>
		
	<@ DEFARE>All</@>
</@>