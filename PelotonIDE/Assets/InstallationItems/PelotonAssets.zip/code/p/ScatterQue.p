<@ LETCNSQUELIT>jj|CustomerID^CompanyName^ContactName^ContactTitle^Address^City^Region^PostalCode^Country^Phone^Fax^</@>
<@ ACTSCTQUE>jj</@>
<@ SAYDMPMEM></@>