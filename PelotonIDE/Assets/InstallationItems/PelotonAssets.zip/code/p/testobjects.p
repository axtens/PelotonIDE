
<@ DEFPRTLITLIT>Student|
	<@ OMT>Trying to make an object for a student record</@>
	<@ DEFATTLIT>Student number|00000000</@>
	<@ DEFATTPRTLIT>Last name|___|put last name here</@>
	<@ DEFATTLIT>First name|put first name here</@>
	<@ DEFMTHPRTLITLIT>mth1|___|this is a mth test</@>
	<@ DEFMTHPRTLITLIT>___PrototypeCreate|___|opening database <@ DEFDBF>c:\school.mdb</@> Opening recordset <@ DEFRST>student</@></@>
	<@ DEFMTHPRTLITLIT>___InstanceCreate|___|hi there from instance create <@ SAYSLFINS>___</@> </@>
	<@ DEFMTHPRTLITLIT>___InstanceDestroy|___|hi there from instance destroy <@ SAYSLFINS>___</@> </@>
	<@ DEFMTHPRTLITLIT>FindMe|___|
		<@ SAYMSG>1</@>
		<@ DEFRSTCAP>select * from student where StuID = "<@ SAYMSG>1</@>"</@>
		<@ IFEFND>
			<@ LETATTFLD>Last name|LastName</@>
			<@ LETATTFLD>First Name|FirstName</@>
			<@ LETATTFLD>Student number|StuID</@>
			found him!!!
		</@>
		<@ ELS>not found</@>
	</@>
	<@ DEFMTHPRTLITLIT>PrintMe|___| 
		<@ OMT> we need to have two versions of this, I think
		StuID	LastName	FirstName	Year	Credits	Hours	State	Gender
		1001	BROWN	PAT	SO	166	60	NJ	M	
		</@>
		<@ IFEFND>
			<@ SAYDMPREC></@>
			<@ SAYDMDREC></@>
			<@ SAYSZERST></@>
			<@ SAYKEY>now</@>
		</@>
		<@ ELS>
			...
		</@>
	</@>
	<@ DEFEVTPRTLIT>evt1|___|lll</@>
</@>
<@ DEFINSPRT>AStudent|Student</@>
<@ DEFINSPRT>BStudent|Student</@>
<@ DEFINSPRT>CStudent|Student</@>
<@ DEFINSPRT>DStudent|Student</@>
<@ DEFINSPRT>EStudent|Student</@>
<@ DEFAREPRTLIT>Student</@>
<@ DEFAREINSLIT>AStudent</@>
<@ ACTMTH>PrintMe</@>
<@ ACTMTHLIT>FindMe|1001</@>
<@ DEFAREINSLIT>BStudent</@>
<@ ACTMTHLIT>FindMe|1019</@>
<@ ACTMTH>PrintMe</@>
<@ ACTMTHLIT>FindMe|771019</@>
<@ ACTMTH>PrintMe</@>
<@ ACTDELINS>AStudent</@>
<@ ACTDELINS>CStudent</@>

