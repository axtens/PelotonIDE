<@ DEFMACLITLIT>one|two</@>
<@ DEFMACLITLIT>two|33</@>

<@ LETVARLIT>q|
<&prot; LETVARLIT>a&pipe;&two;</&prot;>
<&prot; SAYVAR>a</&prot;>
</@>
<@ LETEXPVARVAR>z|q</@>
<@ ACTPRSEXPVAR>q</@>

<@ LETVARLIT>b|2</@>
<@ LETVARLIT>q|<&prot; LETVARLIT>a&pipe;&&one;;</&prot;>&b; + <&prot; SAYVAR>a</&prot;></@>
<@ ACTPRSEX0VAR>q</@>=<@ SAYCLCCAP><@ ACTPRSEX0VAR>q</@></@>








<@ LETVARLIT>X|0</@>
<@ LETVARLIT>D|1</@>
<@ ITEEVALITLIT><@ TSTNUMGTEVARLIT>D|.00001</@>
   <@ LETEXPVARLIT>Y|(1 + X**3)/3</@>
   <@ SAYVAR>Y</@>
   <@ LETABSSUBVARVARVAR>D|X|Y</@>
   <@ LETVARVAR>X|Y</@>
</@>
   <@ SAYVAR>X</@>

