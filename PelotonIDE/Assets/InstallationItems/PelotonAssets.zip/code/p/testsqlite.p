<@ DEFAREPLG>fred</@>
<@ DEFPLGLIT>fred|PDPSQLite.SQLitePlugin</@>
<@ ACTCMDPLGLIT>fred|__PluginName</@>								<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginFriendlyName</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginAuthor</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginCopyright</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginVersionNumber</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDescription</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDimensionality</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDateCreated</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDateModified</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__ThisSessionStarted</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__DatasourceTestIfExists|C:\data\protium\sqlite\test.db</@>		<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__DatasourceDefine|C:\data\protium\sqlite\test.db</@>			<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDefineArea|test1</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordsetDefine|select * from customers</@>				<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDefineArea|test2</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordsetDefine|select * from orders</@>				<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDefineArea|test1</@>						<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordsetSerialisedNames0D</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead1DDumpOfValuePairs</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__FieldRead0DValueByName|Name</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__FieldRead0DValueByNumber|3</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__RecordpointerMoveto|357</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>


<@ ACTCMDPLGLIT>fred|__RecordpointerMoveNext</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>


<@ ACTCMDPLGLIT>fred|__RecordpointerMovePrevious</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>


<@ ACTCMDPLGLIT>fred|__PluginDefineArea|test2</@>						<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordsetSerialisedNames0D</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead1DDumpOfValuePairs</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__FieldRead0DValueByName|Name</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__FieldRead0DValueByNumber|3</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__RecordpointerMoveto|357</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>


<@ ACTCMDPLGLIT>fred|__RecordpointerMoveNext</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>


<@ ACTCMDPLGLIT>fred|__RecordpointerMovePrevious</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>



<@ ACTCMDPLGLIT>fred|__RecordpointerMoveLast</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMoveFirst</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMoveNext</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMoveLast</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMovePrevious</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>



<@ ACTCMDPLGLIT>fred|__RecordsetCountOfElements0D</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordsetCountOfColumns</@>						<@ SAYKEY>__pluginanswer</@>




<@ DEFAREPLG>fred</@>
<@ DEFPLGLIT>fred|PDPSQLite.SQLitePlugin</@>
<@ ACTCMDPLGLITLIT>fred|__DatasourceTestIfExists|C:\data\protium\sqlite\test.db</@>
<@ ACTCMDPLGLITLIT>fred|__DatasourceDefine|C:\data\protium\sqlite\test.db</@>
<@ ACTCMDPLGLITLIT>fred|__PluginDefineArea|test1</@>
<@ ACTCMDPLGLITLIT>fred|__RecordsetDefine|select * from customers</@>
<@ ACTSCTPLG></@>
<@ SAYDMPMEM></@>
<@ ITEENUPLG>fred|
	<@ SAYPDF>PostalCode</@>
	<@ SAYPDF>CustomerID</@>
	<@ SAYPDF>CompanyName</@>
</@>



