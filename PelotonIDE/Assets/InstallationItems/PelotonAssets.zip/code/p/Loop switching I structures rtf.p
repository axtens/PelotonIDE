{\rtf1\ansi\deff0{\fonttbl{\f0\fnil\fcharset0 MS Sans Serif;}{\f1\froman\fprq2\fcharset0 Times New Roman;}{\f2\fdecor\fprq2\fcharset0 Algerian;}}
{\colortbl ;\red255\green0\blue0;}
\viewkind4\uc1\pard\lang1033\f0\fs17 <@ OMT> 
\par \pard\keepn\sb100\sa100\lang2057\b\f1\fs36 Loop switching I: Structures
\par \pard\sb100\sa100\b0\i\fs24 A switched loop is a combination of an iteration and a switch. It can evaluate according to where the cursor in the loop stands 
\par \pard\lang1033\i0\f0\fs17 </@>
\par \cf1\b\f2\fs36 25 iteration FOR loop
\par \cf0\b0\f0\fs17 
\par <@ ITEFORLITLIT>24|
\par <@ EST>\{before\}<BR></@> 
\par <@ EXT>\{after\}</@>
\par <@ GRPLITLIT>3|<HR>Grouping in 3s, we are at number <@ SAYPOSFOR>__current</@><HR></@>
\par \{element <@ SAYPOSFOR>__current</@>\}
\par <@ EVR>\{this is every\}</@>
\par <@ ONG>\{this is ongoing\}</@>
\par <@ MDL>\{this is middle\}</@>
\par <@ INI>\{this is first\}</@>
\par <@ FIN>\{this is last\}</@>
\par <BR>
\par </@>
\par <HR>
\par <H3>0 iteration FOR loop</H3>
\par <@ ITEFORLITLIT>0|
\par element <@ SAYPOSFOR>__current</@>
\par <@ EST>\{before\}<BR></@> 
\par <@ EXT> \{after\}</@>
\par <@ EVR>\{this is every\}</@>
\par <@ ONG>\{this is ongoing\}</@>
\par <@ MDL>\{this is middle\}</@>
\par <@ INI>\{this is first\}</@>
\par <@ FIN>\{this is last\}</@>
\par <@ NVR>\{failure - no results\}<BR></@>
\par <BR>
\par </@>
\par <HR>
\par <H3>Selectede bands in a for loop</H3>
\par <@ ITEFORLITLIT>26|
\par <@ BNDLITLITLIT>4|4|first band<BR></@>
\par <@ BNDLITLITLIT>4|5|<LI>\{element <@ SAYPOSFOR>__current</@>\}<BR></@>
\par <@ BNDLITLITLIT>14|14| 2nd band<BR></@>
\par <@ BNDLITLITLIT>14|15|<LI>\{element <@ SAYPOSFOR>__current</@>\}<BR></@>
\par <@ BNDLITLITLIT>24|24| 3rd band<BR></@>
\par <@ BNDLITLITLIT>24|25|<LI>\{element <@ SAYPOSFOR>__current</@>\}<BR></@>
\par </@>
\par 
\par 
\par <H3>enumerated queue iteration</H3>
\par <@ ITEENULMBQUELIT>q^r^s^t^u^v^w^x^|<BR>
\par <@ GRPLITLIT>3|<HR>Grouping in 3s, we are at number <@ SAYPOSQUE>__current</@><HR>|www </@>
\par \{element <@ SAYELTQUE>__current</@>\}
\par <@ EST>\{before\}</@>
\par <@ EXT>\{after\}</@>
\par <@ INI>\{this is first\}</@>
\par <@ ONG>\{this is ongoing\}</@>
\par <@ MDL>\{this is the middle</@>
\par <@ FIN>\{this is final loop\}</@>
\par <@ EVR>\{this is in every loop\}</@>
\par <@ NVR>\{this is the failure case\}<BR></@>
\par </@>
\par <HR>
\par <H3>enumerated stack iteration</H3>
\par <@ ITEENULMBSTKLIT>2^4^6^8^10^|
\par <@ GRPLITLIT>3|<HR>Grouping in 3s, we are at number <@ SAYPOSSTK>__current</@><HR><BR></@>
\par 
\par \{element <@ SAYELTSTK>__current</@>\}
\par <@ EST>\{before\}<BR></@>
\par <@ EXT>\{after\}</@>
\par <@ INI>\{this is first\}</@>
\par <@ ONG>\{this is ongoing\}</@>
\par <@ MDL>\{this is the middle</@>
\par <@ FIN>\{this is final loop\}</@>
\par <@ EVR>\{this is in every loop\}</@>
\par <@ NVR>\{this is the failure case\}<BR></@>
\par <BR>
\par </@>
\par 
\par \f1\fs24 
\par \f0\fs17 
\par }

