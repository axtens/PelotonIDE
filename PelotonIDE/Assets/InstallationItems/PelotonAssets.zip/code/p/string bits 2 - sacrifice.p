<@ LETVARLIT>j|The cat sat the rat on the mat</@>
<@ ITEFORLITLIT>3|
[<@ SAYRITVAR>j|at</@>][<@ SAYVAR>j</@>]<BR>
</@>
<HR>right "a"<BR>
<@ ITESCS>[<@ SAYSACRITVAR>j|a</@>][<@ SAYVAR>j</@>]<BR></@>
<@ LETVARLIT>j|The cat sat the rat on the mat</@>
<HR>right " "<BR>
<@ ITESCS>[<@ SAYSACRITVAR>j| </@>][<@ SAYVAR>j</@>]<BR></@>
<@ LETVARLIT>j|The cat sat the rat on the mat</@>
<HR>right "at"<BR>
<@ ITESCS>[<@ SAYSACRITVAR>j|at</@>][<@ SAYVAR>j</@>]<BR></@>
<@ LETVARLIT>j|The cat sat the rat on the mat</@>
<HR>right 4<BR>
<@ ITESCS>[<@ SAYSACRITVAR>j|4</@>][<@ SAYVAR>j</@>]<BR></@>
<@ LETVARLIT>j|The cat sat the rat on the mat</@>
<HR>right 9<BR>
<@ ITESCS>[<@ SAYSACRITVAR>j|9</@>][<@ SAYVAR>j</@>]<BR></@>
