<@ DEFAREPLG>fred</@>
<@ DEFPLGLIT>fred|PDPSQLite.SQLitePlugin</@>
<@ ACTCMDPLGLITLIT>fred|__DatasourceTestIfExists|C:\data\protium\sqlite\test.db</@>
<@ ACTCMDPLGLITLIT>fred|__DatasourceDefine|C:\data\protium\sqlite\test.db</@>
<@ ACTCMDPLGLITLIT>fred|__PluginDefineArea|test1</@>
<@ ACTCMDPLGLITLIT>fred|__RecordsetDefine|select * from customers</@>
<@ ACTSCTPLG></@>
<@ SAYDMPMEM></@>
<@ ITEENUPLG>fred|
	<@ SAYPDF>PostalCode</@>
	<@ SAYPDF>CustomerID</@>
	<@ SAYPDF>CompanyName</@>
</@>

<@ ITEENUPLG>fred|
	<@ ACTCMDPLGLITLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>
	<@ ACTCMDPLGLITLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>

</@>


<@ ACTCMDPLGLITLIT>fred|__PluginDefineArea|test1</@>
<@ SAYPLD>CustomerID</@>
<@ ACTCMDPLGLITLITLIT>fred|__FieldRead0DValueByName|CustomerID</@>
<@ LETVARKEY>pia|__pluginanswer</@>
<@ SAYVAR>pia</@>
<@ ACTCMDPLGLITLITLIT>fred|__FieldRead0DValueByName|CompanyName</@>
<@ LETVARKEY>pi2|__pluginanswer</@>
<@ SAYVAR>pi2</@>
<@ ACTSCTPLG></@>
<@ SAYDMPMEM></@>

