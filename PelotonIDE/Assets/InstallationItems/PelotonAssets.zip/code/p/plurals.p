<BR>there are <@ SAYAMTLITLITLIT>0|ox|oxen</@>
<BR>there is <@ SAYAMTLITLITLIT>1|ox|oxen</@>
<BR>there are <@ SAYAMTLITLITLIT>2|ox|oxen</@>
