<@ DEFAREPLG>fred</@>
<@ DEFPLGLIT>fred|PDPTsunami.TsunamiPlugin</@>
<@ ACTCMDPLGLIT>fred|__PluginName</@>								<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginFriendlyName</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginAuthor</@>								<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginCopyright</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginVersionNumber</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDescription</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDimensionality</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDateCreated</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__PluginDateModified</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__ThisSessionStarted</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__DatasourceTestIfExists|C:\data\protium\tsunami\test.dat</@>			<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__DatasourceDefine|C:\data\protium\tsunami\test.dat</@>			<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__DatasourceOpened</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__OrderSetTo|1</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__ComparitorSet|0</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLITLIT>fred|__RecordPointerLocate|    55</@>							<@ SAYKEY>__pluginanswer</@>
<@ IFEBLNKEYLIT>__pluginsuccess|
	<@ SAYKEY>__pluginanswer</@>
	<@ ACTCMDPLGLIT>fred|__RecordsetSerialisedNames0D</@>						<@ SAYKEY>__pluginanswer</@>
	<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>						<@ SAYKEY>__pluginanswer</@>
	<@ ACTCMDPLGLIT>fred|__RecordRead1DDumpOfValuePairs</@>							<@ SAYKEY>__pluginanswer</@>
	<@ ACTCMDPLGLITLIT>fred|__FieldRead0DValueByName|Name</@>				<@ SAYKEY>__pluginanswer</@>
	<@ ACTCMDPLGLITLIT>fred|__FieldRead0DValueByNumber|3</@>					<@ SAYKEY>__pluginanswer</@>
</@>
<@ ELS>

</@>




<@ ACTCMDPLGLITLIT>fred|__RecordpointerMoveto|357</@>					<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>


<@ ACTCMDPLGLIT>fred|__RecordpointerMoveNext</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>


<@ ACTCMDPLGLIT>fred|__RecordpointerMovePrevious</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>






<@ ACTCMDPLGLIT>fred|__RecordpointerLast</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>				<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMoveFirst</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>				<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMoveNext</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>				<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMoveLast</@>							<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>				<@ SAYKEY>__pluginanswer</@>

<@ ACTCMDPLGLIT>fred|__RecordpointerMovePrevious</@>						<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>				<@ SAYKEY>__pluginanswer</@>



<@ ACTCMDPLGLIT>fred|__RecordsetCountOfElements0D</@>								<@ SAYKEY>__pluginanswer</@>
<@ ACTCMDPLGLIT>fred|__RecordsetCountOfColumns</@>							<@ SAYKEY>__pluginanswer</@>





<@ ITEENUPLG>fred|
	<@ ACTCMDPLGLIT>fred|__RecordpointerPosition</@>						<@ SAYKEY>__pluginanswer</@>
	<@ ACTCMDPLGLIT>fred|__RecordRead0DSerialisedValues</@>					<@ SAYKEY>__pluginanswer</@>

</@>
