<H3>25 iteration FOR loop</H3>
<@ ITEFORLITLIT>24|
<@ EST>{before}<BR></@> 
<@ EXT>{after}</@>
<@ GRPLITLIT>3|<HR>Grouping in 3s, we are at number <@ SAYPOSFOR>__current</@><HR></@>
{element <@ SAYPOSFOR>__current</@>}
<@ EVR>{this is every}</@>
<@ ONG>{this is ongoing}</@>
<@ MDL>{this is middle}</@>
<@ INI>{this is first}</@>
<@ FIN>{this is last}</@>
<BR>
</@>
<HR>
<H3>0 iteration FOR loop</H3>
<@ ITEFORLITLIT>0|
element <@ SAYPOSFOR>__current</@>
<@ EST>{before}<BR></@> 
<@ EXT> {after}</@>
<@ EVR>{this is every}</@>
<@ ONG>{this is ongoing}</@>
<@ MDL>{this is middle}</@>
<@ INI>{this is first}</@>
<@ FIN>{this is last}</@>
<@ NVR>{failure - no results}<BR></@>
<BR>
</@>
<HR>
<H3>Selectede bands in a for loop</H3>
<@ ITEFORLITLIT>26|
<@ BNDLITLITLIT>4|4|first band<BR></@>
<@ BNDLITLITLIT>4|5|<LI>{element <@ SAYPOSFOR>__current</@>}<BR></@>
<@ BNDLITLITLIT>14|14| 2nd band<BR></@>
<@ BNDLITLITLIT>14|15|<LI>{element <@ SAYPOSFOR>__current</@>}<BR></@>
<@ BNDLITLITLIT>24|24| 3rd band<BR></@>
<@ BNDLITLITLIT>24|25|<LI>{element <@ SAYPOSFOR>__current</@>}<BR></@>
</@>


<H3>enumerated queue iteration</H3>
<@ ITEENULMBQUELIT>q^r^s^t^u^v^w^x^|<BR>
<@ GRPLITLIT>3|<HR>Grouping in 3s, we are at number <@ SAYPOSQUE>__current</@><HR>|www </@>
{element <@ SAYELTQUE>__current</@>}
<@ EST>{before}</@>
<@ EXT>{after}</@>
<@ INI>{this is first}</@>
<@ ONG>{this is ongoing}</@>
<@ MDL>{this is the middle</@>
<@ FIN>{this is final loop}</@>
<@ EVR>{this is in every loop}</@>
<@ NVR>{this is the failure case}<BR></@>
</@>
<HR>
<H3>enumerated stack iteration</H3>
<@ ITEENULMBSTKLIT>2^4^6^8^10^|
<@ GRPLITLIT>3|<HR>Grouping in 3s, we are at number <@ SAYPOSSTK>__current</@><HR><BR></@>

{element <@ SAYELTSTK>__current</@>}
<@ EST>{before}<BR></@>
<@ EXT>{after}</@>
<@ INI>{this is first}</@>
<@ ONG>{this is ongoing}</@>
<@ MDL>{this is the middle</@>
<@ FIN>{this is final loop}</@>
<@ EVR>{this is in every loop}</@>
<@ NVR>{this is the failure case}<BR></@>
<BR>
</@>
