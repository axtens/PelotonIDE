<h2>Rolling a dice 6 times</h2> <@ SAYROLLIT>6</@>
<h2>Tossing a coin 2 times </h2> <@ SAYTOSLIT>2</@>
<h2>Dealing hands</h2> (can deal up to up to 52) cards without repeating 
<@ SAYHNDLIT>5</@>
<h2>APL deal function</h2> 
5 random integers between 6 and 100
<@ SAYDEALIT>6|100|5</@><BR>
