<@ DEFPRTLITLIT>Student|
	<@ OMT>Trying to make an object for a student record</@>
	<@ DEFATTLIT>Student number|00000000</@>
	<@ DEFATTPRTLIT>Last name|___|put last name here</@>
	<@ DEFATTLIT>First name|put first name here</@>
	<@ DEFMTHPRTLITLIT>mth1|___|this is a mth test</@>
	<@ DEFMTHPRTLITLIT>___PrototypeCreate|___|<@ SAYLIT>hi there from prototype create</@></@>
	<@ DEFMTHPRTLITLIT>___InstanceCreate|___|hi there from instance create <@ SAYSLFOBJ>___</@> </@>
	<@ DEFEVTPRTLIT>evt1|___|lll</@>
</@>
<@ DEFINSPRT>st1|Student</@>
<@ DEFINSPRT>st2|Student</@>
<@ LETATTINSPRTLIT>Last name|st1|Student|Smith</@>
<@ LETATTINSPRTLIT>First name|st1|Student|John</@>
<@ SAYATTINSPRT>Last name|st1|Student</@>
<@ SAYATTINSPRT>First name|st1|Student</@>
<@ LETATTINSPRTLIT>Last name|st1|Student|Johns</@>
<@ LETATTINSPRTLIT>First name|st1|Student|Peter</@>

<@ DEFAREPRTLIT>Student</@>
<@ DEFAREINSLIT>st1</@>
<@ SAYATT>Last name</@>
<@ SAYATT>First name</@>
<@ DEFAREINSLIT>st2</@>
<@ SAYATT>Last name</@>
<@ SAYATT>First name</@>
