<@ RST>select * from tblBits where idBit < 12</@>
<@ LETCNSQUELIT>j|x^y^z^</@>
<@ LETCNSSTKLIT>j|p^q^r</@>
<BR>
<@ ITEENUQUE>j|<FONT COLOR=blue><@ SAYELTQUE>j</@></FONT></@><BR>
<@ FORLITLIT>4|<FONT COLOR=red>a</FONT></@><BR>
<@ FORLITLIT>7|<FONT COLOR=green>b</FONT></@><BR>
<@ FORLITLITLIT>5|2|<FONT COLOR=brown>c</FONT></@><BR>
<@ ITEENUSTK>j|<FONT COLOR=yellow><@ SAYELTSTK>j</@></FONT></@><BR>
<@ FORLITLITLIT>11|9|<FONT COLOR=orange>d</@></FONT><BR>
<@ ITERST><FONT COLOR=white><@ SAYFLD>idBit</@></FONT></@>

<HR>
<TABLE><TR>
<TD valign=top>
Stop at lowest<HR>
<@ SYN>lowest|<BR>
<@ ITEENUQUE>j|<FONT COLOR=blue><@ SAYELTQUE>j</@></FONT></@><BR>
<@ FORLITLIT>4|<FONT COLOR=red>a</FONT></@><BR>
<@ FORLITLIT>7|<FONT COLOR=green>b</FONT></@><BR>
<@ FORLITLITLIT>5|2|<FONT COLOR=brown>c</FONT></@><BR>
<@ ITEENUSTK>j|<FONT COLOR=yellow><@ SAYELTSTK>j</@></FONT></@><BR>
<@ FORLITLITLIT>11|9|<FONT COLOR=orange>d</FONT></@><BR>
<@ ITERST><FONT COLOR=white><@ SAYFLD>idBit</@></FONT></@></@><BR>
</TD>
<TD valign=top>
Stop at middle<HR>
<@ SYN>middle|<BR>
<@ ITEENUQUE>j|<FONT COLOR=blue><@ SAYELTQUE>j</@></FONT></@><BR>
<@ FORLITLIT>4|<FONT COLOR=red>a</FONT></@><BR>
<@ FORLITLIT>7|<FONT COLOR=green>b</FONT></@><BR>
<@ FORLITLITLIT>5|2|<FONT COLOR=brown>c</FONT></@><BR>
<@ ITEENUSTK>j|<FONT COLOR=yellow><@ SAYELTSTK>j</@></FONT></@><BR>
<@ FORLITLITLIT>11|9|<FONT COLOR=orange>d</FONT></@><BR>
<@ ITERST><FONT COLOR=white><@ SAYFLD>idBit</@></FONT></@></@><BR>
</TD>
<TD valign=top>
Stop at highest<HR>
<@ SYN>|<BR>
<@ ITEENUQUE>j|<FONT COLOR=blue><@ SAYELTQUE>j</@></FONT></@><BR>
<@ FORLITLIT>4|<FONT COLOR=red>a</FONT></@><BR>
<@ FORLITLIT>7|<FONT COLOR=green>b</FONT></@><BR>
<@ FORLITLITLIT>5|2|<FONT COLOR=brown>c</FONT></@><BR>
<@ ITEENUSTK>j|<FONT COLOR=yellow><@ SAYELTSTK>j</@></FONT></@><BR>
<@ FORLITLITLIT>11|9|<FONT COLOR=orange>d</FONT></@><BR>
<@ ITERST><FONT COLOR=white><@ SAYFLD>idBit</@></FONT></@></@><BR>
</TD>
</TR>
</TABLE>
