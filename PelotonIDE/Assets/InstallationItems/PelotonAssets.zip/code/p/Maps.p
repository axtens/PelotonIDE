<@ DEFAREMAP>fruit</@>
<@ LETMAPLIT>a|apple</@>
<@ LETMAPLIT>b|banana</@>
<@ LETMAPLIT>c|canteloupe</@>
<@ LETMAPLIT>d|durian</@>
<@ LETMAPLIT>e|elderberry</@>
<@ LETMAPLIT>f|fig</@>
<@ LETMAPLIT>g|grape</@>
<@ LETMAPLIT>h|honeydew</@>
<@ LETMAPLIT>i|irriwady</@>
<@ LETMAPLIT>j|jaffa</@>
<@ LETMAPLIT>k|kiwifruit</@>
<@ LETMAPLIT>l|lemon</@>
<@ LETMAPLIT>m|melon</@>
<@ LETMAPLIT>n|navel</@>
<@ LETMAPLIT>o|orange</@>
<@ LETMAPLIT>p|pear</@>
<@ LETMAPLIT>q|quince</@>
<@ LETMAPLIT>r|raspberry</@>
<@ LETMAPLIT>s|squash</@>
<@ LETMAPLIT>t|tomato</@>
<@ LETMAPLIT>u|ugli</@>
<@ LETMAPLIT>v|valencia</@>
<@ LETMAPLIT>w|watermelons</@>
<@ LETMAPLIT>x|Xylomelum</@>
<@ LETMAPLIT>y|yam</@>
<@ LETMAPLIT>z|zebra</@>
<@ LETMAPLIT>th|thornapple</@>
<@ LETMAPLIT>st|stonefruit</@>
<BR>if I asked what fruit was <em>th</em> it would say: <em><em><@ SAYMAP>th</@></em></em>
<BR>Assigning the value of <em>b</em> to a variable now: <em><em><@ LETVARMAP>freddo|b</@><@ SAYVAR>freddo</@></em></em>
<BR>Assigning <em>g</em> the value of guava: <@ LETMAPLIT>g|guava</@><em><em><@ SAYMAP>g</@></em></em>
<BR>and now dumping the entire dictionary:<Dir>
<BR><em><@ SAYP2HREPDMPMAPLITLIT>fruit|^|=</@></em></Dir>
