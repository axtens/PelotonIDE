<@ OMT> Anonymised variables - creating variables with no name

We show how the PUT and CPS (capsule) pair work. This is similar to the capture CAP system, except that instead of writing to a captured screen, the value itself is passed directrly to the calling system, and only the desired result is passed out to it, rather than all of it.

This example encapsulates the output of the addition of 2 to an existing variable, then adds that to three. The variable is made inside the encapsulated code, byt the addition of 1 and 4. THe final section of the snippet (outside the encapsulated block) shows binding order by printing the value of the created variable.

Effectively, this is the sum 3 + ((1 + 4) + 2), with the initial (1+4) preserved. 
</@>
the grand total is <@ SAYADDLITCPS>3|<@ LETADDVARLITLIT>subtotal|1|4</@><@ PUTADDVARLIT>subtotal|2</@></@>
the subtotal was <@ SAYVAR>subtotal</@>



