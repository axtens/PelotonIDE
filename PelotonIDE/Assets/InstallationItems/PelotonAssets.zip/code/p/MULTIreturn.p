 Integer divide : 131/6=<@ SAYDVILITLIT>131|6</@><BR>
Remainder: 131/6=<@ SAYMODLITLIT>131|6</@><BR>
Divide with remainder: 131/6=<@ SAYDVRLITLIT>131|6</@><BR>
<HR>
Absissa: <@ SAYFLRLIT>1.135</@><BR>
Mantissa: <@ SAYMANLIT>1.135</@><BR>
Absissa and mantissa: <@ SAYAAMLIT>1.135</@><BR>
<HR>
Floor: <@ SAYFLRLIT>1.135</@><BR>
Ceiling: <@ SAYCLNLIT>1.135</@><BR>
Ceiling and floor: <@ SAYFCLLIT>1.135</@>
