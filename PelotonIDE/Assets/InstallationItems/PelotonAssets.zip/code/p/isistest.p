<@ DEFAREPLG>DataPlugin</@>
<@ DEFPLGLIT>DataPlugin|PDPIsis</@>
<@ ACTCMDPLGLITLIT>DataPlugin|__PluginDefineArea|Test</@>
<@ SAYACTCMDPLGLITLIT>DataPlugin|__DatabaseDefine|C:\protium\data\isis\cds</@>


<@ SAYSZEPLG>DataPlugin</@>
<@ SAYPOSPLG>DataPlugin</@>
<@ SAYSOPPDF>70</@>
<@ SAYSPLPDF>70</@>

<@ ITEENUPLG>DataPlugin| 
	<@ ACTCMDPLGLITLIT>DataPlugin|__RecordRead1DFormattedValue</@><@ SAYKEY>__pluginanswer</@>
</@> 