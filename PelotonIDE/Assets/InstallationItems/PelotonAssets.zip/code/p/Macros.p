<@ DEFMACLITLIT>one|two</@>
<@ DEFMACLITLIT>two|33</@>

<@ LETVARLIT>q|
<&prot; LETVARLIT>a&pipe;&two;</&prot;>
<&prot; SAYVAR>a</&prot;>
</@>
<BR><BR><BR>
<@ LETEXPVARVAR>z|q</@>
[<@ SAYVAR>z</@>]
<BR>
<@ ACTPRSEXPVAR>q</@>
<BR>

<@ LETVARLIT>b|2</@>
<@ LETVARLIT>q|<&prot; LETVARLIT>a&pipe;&&one;;</&prot;>&b; + <&prot; SAYVAR>a</&prot;></@>
<@ ACTPRSEX0VAR>q</@>=<@ SAYCLCCAP><@ ACTPRSEX0VAR>q</@></@>
