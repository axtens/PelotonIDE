<@ DEFKOPLIT>RQU|REDQUE</@>
<@ DEFKOPLIT>PUQ|GETHIDMINREDLMXQUELIT</@>
<@ DEFUDSLITLITLIT>ZZZ|transformer|
<TR>
<TD><@ SAYMINRQU>__current</@></TD>
<TD><@ SAYLQURQU>__current</@></TD>
<TD><@ SAYMDNRQU>__current</@></TD>
<TD><@ SAYUQURQU>__current</@></TD>
<TD><@ SAYMAXRQU>__current</@></TD>
<TD><@ SAYAVGRQU>__current</@></TD>
<TD><@ SAYGMNRQU>__current</@></TD>
<TD><@ SAYHMNRQU>__current</@></TD>
<TD><@ SAYSTDRQU>__current</@></TD>
<TD><@ SAYVRNRQU>__current</@></TD>
<TD><@ SAYKRTRQU>__current</@></TD>
<TD><@ SAYAVDRQU>__current</@></TD>
<TD><@ SAYDVQRQU>__current</@></TD>
<TD><@ SAYSKWRQU>__current</@></TD>
</TR>
<@ DEFNULQUE>__current</@>
</@>
<TABLE border=1>
<TR> <TH>MIN</TH> <TH>LQU</TH> <TH>MDN</TH> <TH>UQU</TH> <TH>MAX</TH> <TH>AVG</TH> <TH>GMN</TH> <TH>HMN</TH> <TH>STD</TH> <TH>VRN</TH> <TH>KRT</TH> <TH>AVD</TH> <TH>DVQ</TH> <TH>SKW</TH> </TR>

<@ PUQ>1^4^8^9^</@>
<@ SAYZZZLIT></@>
<@ PUQ>1^3^5^7^9^11^15^</@>
<@ SAYZZZLIT></@>
<@ PUQ>2^4^6^8^</@>
<@ SAYZZZLIT></@>
</TABLE>
