<@ ACTSNKLIT>Letit.txt</@>1^2^3^4^5^6^7^8^9^
<@ ACTSNKLIT>off</@>
<@ ACTRFLQUELIT>h|Letit.txt</@>
<@ ACTINVENTQUE>h</@>
<@ SAYDMPQUE>h</@>
<@ ACTWFLQUELIT>h|Letit2.txt</@>
<@ ACTRFLQUELIT>h2|Letit2.txt</@>
[<@ SAYDMPQUE>h2</@>]
