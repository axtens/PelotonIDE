 Constructing (<EM><EM>CNS</EM></EM>) a queue from a deal (<EM><EM>DEA</EM></EM>) of random numbers,<BR> duping (<EM><EM>DUP</EM></EM>) it a few times so that the subsequent is meaningful<@ LETCNSDEAQUELITLITLIT>q|6|100|9</@>, <@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><@ ACTDUPQUE>q</@><BR> and dumping (<EM><EM>DMP</EM></EM>) it:<BR><EM>{<@ SAYDMPQUELITLIT>q|,|}</EM></@>
Reducing (<EM><EM>RED</EM></EM>) q via statistical functions: <UL>
<LI>average of the absolute deviations (<EM><EM>AVD</EM></EM>) <EM><@ SAYAVDREDQUE>q</@></EM></LI>
<LI>average (<EM><EM>AVG</EM></EM>) <EM><@ SAYAVGREDQUE>q</@></EM></LI>
<LI>geometric mean (<EM><EM>GMN</EM></EM>) <EM><@ SAYGMNREDQUE>q</@></EM></LI>
<LI>harmonic mean (<EM><EM>HMN</EM></EM>) <EM><@ SAYHMNREDQUE>q</@></EM></LI>
<LI>kurtosis (<EM><EM>KRT</EM></EM>) <EM><@ SAYKRTREDQUE>q</@></EM></LI>
<LI>lower quartile (<EM><EM>LQU</EM></EM>) <EM><@ SAYLQUREDQUE>q</@></EM></LI>
<LI>maximum (<EM><EM>MAX</EM></EM>) <EM><@ SAYMAXREDQUE>q</@></EM></LI>
<LI>median (<EM><EM>MDN</EM></EM>) <EM><@ SAYMDNREDQUE>q</@></EM></LI>
<LI>minimum (<EM><EM>MIN</EM></EM>) <EM><@ SAYMINREDQUE>q</@></EM></LI>
<LI>40% percentile (<EM><EM>PTL</EM></EM>) <EM><@ SAYPTLREDQUELIT>q|.4</@></EM></LI>
<LI>Face percentile rank(<EM><EM>PTR</EM></EM>) <EM><@ SAYPTRREDQUEQUE>q|q</@></EM></LI>
<LI>skew (<EM><EM>SKW</EM></EM>) <EM><@ SAYSKWREDQUE>q</@></EM></LI>

<LI>sum of squares (<EM><EM>SSQ</EM></EM>) <EM><@ SAYSSQREDQUE>q</@></EM></LI>
<LI>sum of squares of deviations (<EM><EM>DVQ</EM></EM>) <EM><@ SAYDVQREDQUE>q</@></EM></LI>
<LI>standard deviation  (<EM><EM>STD</EM></EM>) <EM><@ SAYSTDREDQUE>q</@></EM></LI>

<LI>population standard deviation  (<EM><EM>SDP</EM></EM>) <EM><@ SAYSDPREDQUE>q</@></EM></LI>

<LI>span (range) (<EM><EM>SPN</EM></EM>) <EM><@ SAYSPNREDQUE>q</@></EM></LI>
<LI>upper quartile (<EM><EM>UQU</EM></EM>) <EM><@ SAYUQUREDQUE>q</@></EM></LI>
<LI>variance (<EM><EM>VRN</EM></EM>) <EM><@ SAYVRNREDQUE>q</@></EM></LI>
<LI>population variance (<EM><EM>VPN</EM></EM>) <EM><@ SAYVPNREDQUE>q</@></EM></LI>
<LI>rank (<EM><EM>RNK</EM></EM>) of face value (<EM><@ SAYQUE>q</@></EM>) <EM><@ SAYRNKREDQUEQUE>q|q</@></EM></LI>
<LI>mode (<EM><EM>MDE</EM></EM>) <EM><@ SAYMDEREDQUE>q</@></EM></LI>
<LI>frequency of face-value (<EM><EM>FRQ</EM></EM>) <EM><@ SAYFRQREDQUEQUE>q|q</@></EM></LI>
<LI>number of unique (<EM><EM>UNQ</EM></EM>) <EM><@ SAYUNQREDQUE>q</@></EM> vs. count (<EM><EM>SZE</EM></EM>) <EM><@ SAYSZEQUE>q</@></EM></LI>


</UL>
