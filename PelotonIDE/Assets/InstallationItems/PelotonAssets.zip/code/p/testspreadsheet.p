<@ DEFTAB>off</@>
<@ DEFAREWBK>test</@>
<@ DEFWBK>c:\protium\data\excel\testtest.xls</@>
<@ DEFAREWKS>test2</@>
<@ DEFWKS>EmployeesCatalogue</@>
<@ DEFAREWCS>testwcs</@>
<@ DEFWCSLIT>A1:B148</@>
<@ ITEENUWCSLIT>testwcs|
	<@ SAYCEL>___</@> <@ SAYNXTCEL>___</@>
</@>
<@ ITEENUWCSLIT>testwcs|x</@>
<@ OMT>
	<@ SAYCEL>___</@> <@ SAYNXTCEL>___</@>
	<@ ACTMOVCEL></@>
	<@ SAYCEL>___</@> <@ SAYNXTCEL>___</@>
</@>


<@ OMT>
	<@ DEFAREWKS>test</@>
	<@ DEFWKS>employees</@>
	<@ DEFAREWKS>test2</@>
	<@ DEFWKS>EmployeesCatalogue</@>
	<@ ITEFORLITLIT>100|<@ SAYCEL>___</@> <@ SAYNXTCEL>___</@> <@ ACTMOVCEL></@></@> 
</@> 



<@ OMT>
<@ ITEWCSLIT>testwcs|x</@>
</@>